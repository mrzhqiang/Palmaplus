﻿Android
请把所有文件放在SD卡的nagrand/lua目录下，如果没有，请创建!